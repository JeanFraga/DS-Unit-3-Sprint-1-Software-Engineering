# ds_func
some data science helper functions
