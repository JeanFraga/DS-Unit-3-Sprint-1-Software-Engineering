"""
lambdata - data science helper functions
"""
from sklearn.model_selection import train_test_split

# train, validation, test split
def tvt_split(X, tr_sz, val_sz, test_sz):
    X = X.copy()
    train, test = train_test_split(X, train_size=(tr_sz + val_sz), test_size=test_sz)
    train, val = train_test_split(train, train_size=tr_sz, test_size=val_sz)
    return train.shape, val.shape, test.shape

# make a list a column of a dataframe
def as_col(aList, X):
    X = X.copy()
    X = X['alist']
    return X